# FlashShare — Android Flutter starter

This is the first starter version of your Android file-sharing app.

## What works in this starter
- Select multiple files of any type using Android's file picker.
- Share selected files through Android's native sharing sheet.
- Basic Send / Receive / History / Settings screens.
- File type icons and file sizes.

## Important limitation
This is NOT yet a full ShareMe/EasyShare-style direct transfer app.
The current Send button opens Android's system sharing menu. Direct phone-to-phone
transfer inside FlashShare (Wi-Fi hotspot/local network, QR pairing, progress,
and receive flow) is the next development milestone.

## Build an APK
You need Flutter and Android SDK installed on a computer, or a cloud Flutter build
environment that supports Android APK builds.

Commands:
1. `flutter pub get`
2. `flutter build apk --release`
3. APK output: `build/app/outputs/flutter-apk/app-release.apk`

This source folder is a Flutter project, not an APK file. The APK can be created
after building it with Flutter/Android SDK.
