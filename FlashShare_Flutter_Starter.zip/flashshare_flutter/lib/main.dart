import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';

void main() => runApp(const FlashShareApp());

class FlashShareApp extends StatelessWidget {
  const FlashShareApp({super.key});

  @override
  Widget build(BuildContext context) {
    const seed = Color(0xFF6750D8);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'FlashShare',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: seed, brightness: Brightness.light),
        scaffoldBackgroundColor: const Color(0xFFF7F6FC),
        cardTheme: CardTheme(
          elevation: 0,
          color: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
        ),
      ),
      home: const HomePage(),
    );
  }
}

class TransferRecord {
  TransferRecord(this.name, this.size, this.time);
  final String name;
  final int size;
  final DateTime time;
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tab = 0;
  List<PlatformFile> selected = [];
  final List<TransferRecord> history = [];

  String prettySize(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
    if (bytes < 1024 * 1024 * 1024) return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
    return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(2)} GB';
  }

  Future<void> pickFiles() async {
    final result = await FilePicker.platform.pickFiles(
      allowMultiple: true,
      type: FileType.any,
      withData: false,
    );
    if (result == null) return;
    setState(() => selected = result.files.where((f) => f.path != null).toList());
  }

  Future<void> shareFiles() async {
    final paths = selected.map((f) => f.path).whereType<String>().toList();
    if (paths.isEmpty) return;
    await Share.shareXFiles(
      paths.map((p) => XFile(p)).toList(),
      subject: 'Files shared with FlashShare',
      text: 'Shared using FlashShare',
    );
    if (!mounted) return;
    setState(() {
      for (final f in selected) {
        history.insert(0, TransferRecord(f.name, f.size, DateTime.now()));
      }
    });
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Android sharing menu opened. Choose an app or nearby sharing option.')),
    );
  }

  IconData fileIcon(String name) {
    final ext = name.split('.').last.toLowerCase();
    if (['jpg','jpeg','png','gif','webp','heic'].contains(ext)) return Icons.image_rounded;
    if (['mp4','mkv','mov','avi'].contains(ext)) return Icons.video_file_rounded;
    if (['mp3','wav','aac','m4a'].contains(ext)) return Icons.audio_file_rounded;
    if (ext == 'pdf') return Icons.picture_as_pdf_rounded;
    if (['apk','xapk'].contains(ext)) return Icons.android_rounded;
    return Icons.insert_drive_file_rounded;
  }

  Widget sendPage() {
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 18, 20, 110),
      children: [
        const Text('Share anything.', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800, letterSpacing: -1)),
        const SizedBox(height: 6),
        Text('Fast, simple file sharing starts here.', style: TextStyle(color: Colors.grey.shade600, fontSize: 15)),
        const SizedBox(height: 22),
        Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Color(0xFF6D5AE6), Color(0xFF9B68E8)], begin: Alignment.topLeft, end: Alignment.bottomRight),
            borderRadius: BorderRadius.circular(26),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Icon(Icons.send_rounded, color: Colors.white, size: 34),
            const SizedBox(height: 15),
            const Text('Send files', style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            const Text('Photos, videos, documents, music and more.', style: TextStyle(color: Colors.white70, fontSize: 14)),
            const SizedBox(height: 18),
            FilledButton.icon(
              onPressed: pickFiles,
              icon: const Icon(Icons.add_rounded),
              label: const Text('Choose files'),
              style: FilledButton.styleFrom(backgroundColor: Colors.white, foregroundColor: const Color(0xFF604BD0), padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 13)),
            ),
          ]),
        ),
        const SizedBox(height: 22),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          const Text('Selected files', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
          Text('${selected.length} selected', style: TextStyle(color: Colors.grey.shade600)),
        ]),
        const SizedBox(height: 10),
        if (selected.isEmpty)
          Card(child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 30, horizontal: 18),
            child: Column(children: [
              Icon(Icons.folder_open_rounded, size: 42, color: Colors.deepPurple.shade200),
              const SizedBox(height: 10),
              const Text('No files selected', style: TextStyle(fontWeight: FontWeight.w600)),
              const SizedBox(height: 4),
              Text('Tap “Choose files” to get started.', style: TextStyle(color: Colors.grey.shade600)),
            ]),
          ))
        else ...[
          ...selected.map((f) => Card(
            child: ListTile(
              leading: CircleAvatar(backgroundColor: const Color(0xFFF0EDFF), child: Icon(fileIcon(f.name), color: const Color(0xFF6750D8))),
              title: Text(f.name, maxLines: 1, overflow: TextOverflow.ellipsis),
              subtitle: Text(prettySize(f.size)),
              trailing: IconButton(icon: const Icon(Icons.close_rounded), onPressed: () => setState(() => selected.remove(f))),
            ),
          )),
          const SizedBox(height: 10),
          FilledButton.icon(
            onPressed: shareFiles,
            icon: const Icon(Icons.share_rounded),
            label: const Text('Share selected files'),
            style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(52)),
          ),
        ],
        const SizedBox(height: 18),
        Card(child: ListTile(
          leading: const Icon(Icons.info_outline_rounded, color: Colors.deepPurple),
          title: const Text('Starter version'),
          subtitle: const Text('This first build uses Android’s sharing menu. Direct FlashShare-to-FlashShare transfer is the next development step.'),
        )),
      ],
    );
  }

  Widget receivePage() => Center(
    child: Padding(
      padding: const EdgeInsets.all(28),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Container(width: 104, height: 104, decoration: const BoxDecoration(color: Color(0xFFECE8FF), shape: BoxShape.circle), child: const Icon(Icons.download_rounded, size: 52, color: Color(0xFF6750D8))),
        const SizedBox(height: 20),
        const Text('Receive files', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Text('Direct receiving between two FlashShare phones will be added in the next version.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey.shade600, height: 1.5)),
      ]),
    ),
  );

  Widget historyPage() => history.isEmpty
      ? Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          const Icon(Icons.history_rounded, size: 58, color: Color(0xFFB8AEDF)),
          const SizedBox(height: 12),
          const Text('No sharing activity yet', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
          const SizedBox(height: 5),
          Text('Your recent shares will appear here.', style: TextStyle(color: Colors.grey.shade600)),
        ]))
      : ListView(padding: const EdgeInsets.all(16), children: [
          const Text('Recent activity', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          ...history.map((r) => Card(child: ListTile(
            leading: const CircleAvatar(child: Icon(Icons.check_rounded)),
            title: Text(r.name, maxLines: 1, overflow: TextOverflow.ellipsis),
            subtitle: Text('${prettySize(r.size)} • ${r.time.hour.toString().padLeft(2,'0')}:${r.time.minute.toString().padLeft(2,'0')}'),
          ))),
        ]);

  Widget settingsPage() => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('Settings', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
    const SizedBox(height: 14),
    const Card(child: ListTile(leading: Icon(Icons.info_outline), title: Text('FlashShare'), subtitle: Text('Version 1.0 starter'))),
    const Card(child: ListTile(leading: Icon(Icons.privacy_tip_outlined), title: Text('Privacy'), subtitle: Text('Files are selected by you and passed to Android’s share interface.'))),
  ]);

  @override
  Widget build(BuildContext context) {
    final pages = [sendPage(), receivePage(), historyPage(), settingsPage()];
    return Scaffold(
      appBar: AppBar(
        title: Row(children: const [
          Icon(Icons.bolt_rounded, color: Color(0xFF6750D8), size: 29),
          SizedBox(width: 7),
          Text('FlashShare', style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: -.5)),
        ]),
        backgroundColor: const Color(0xFFF7F6FC),
      ),
      body: IndexedStack(index: tab, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.send_outlined), selectedIcon: Icon(Icons.send_rounded), label: 'Send'),
          NavigationDestination(icon: Icon(Icons.download_outlined), selectedIcon: Icon(Icons.download_rounded), label: 'Receive'),
          NavigationDestination(icon: Icon(Icons.history_outlined), selectedIcon: Icon(Icons.history_rounded), label: 'History'),
          NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings_rounded), label: 'Settings'),
        ],
      ),
    );
  }
}
